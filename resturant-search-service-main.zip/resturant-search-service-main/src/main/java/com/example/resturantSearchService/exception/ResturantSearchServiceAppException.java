package com.example.resturantSearchService.exception;

public class ResturantSearchServiceAppException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ResturantSearchServiceAppException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ResturantSearchServiceAppException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ResturantSearchServiceAppException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ResturantSearchServiceAppException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ResturantSearchServiceAppException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

 
	
}
